﻿export default {
    "graphqlEndpoint": "https://ru54z26rjvgorddoawepsqqisi.appsync-api.ap-south-1.amazonaws.com/graphql",
    "region": "ap-south-1",
    "authenticationType": "API_KEY",
    "apiKey": "da2-ycpzrwbofrbrnha4bji5kwddlq"
}