import React, { Component } from 'react'

class Message extends Component {
  render() {
    return (
        <li class="list-group-item">
          {this.props.item.username} says "{this.props.item.message}"
        </li>
    )
  }
}

export default Message