import React, { Component } from 'react'
import { graphql } from 'react-apollo'
import Message from './Message'
import ListMessagesQuery from '../queries/ListMessages'

class Messages extends Component {

  render() {
      if (this.props.listMessages && this.props.listMessages.loading) {
        return <div>Loading</div>
      }
      if (this.props.listMessages && this.props.listMessages.error) {
        return <div>Error</div>
      }
      const msgsToRender = this.props.listMessages.listMessages.items

    return (
      <div>
        <ul class="list-group">
      {msgsToRender.map(item => <Message key={item.id} item={item} />)}
      </ul>
      </div>
    )
  }
}


export default graphql(ListMessagesQuery, { name: 'listMessages' }) (Messages)
