import React, { Component } from 'react'
import { graphql } from 'react-apollo'
import uuidV4 from 'uuid'
import CreateMessageQuery from '../queries/CreateMessage'

class AddMessage extends Component {
  handleSubmit(e) {
    e.preventDefault()
    let formData = new FormData(this.form)
    this.props
      .mutate({ variables: { 
          id: uuidV4(),
          username: formData.get('name'),
          message: formData.get('message')
        } })
      .then(res => {
        if (res.data.createMessage.formErrors === null) {
          console.log(res.data.createMessage.formErrors)
        } else {
          console.log(res.data.createMessage.formErrors)
        }
      })
      .catch(err => {
        console.log(err)
      })
  }

  render() {
    return (
      <div>
        <form
          ref={ref => (this.form = ref)}
          onSubmit={e => this.handleSubmit(e)}
          class = "stylize"
        >
          <div class="row">
            <div class="col">
              <input name="name" placeholder="Name" class="form-control"/>
            </div>
            <div class="col">
              <input id="message" name="message" placeholder="Say something" class="form-control"/>
            </div>
          </div>
          <button type="submit" class="btn btn-primary btn-lg btn-block">Send Message</button>
        </form>
      </div>
    )
  }
}
AddMessage = graphql(CreateMessageQuery)(AddMessage)
export default AddMessage

//export default graphql(POST_MUTATION, { name: 'createMessages' })(AddMessage)
//export default AddMessage