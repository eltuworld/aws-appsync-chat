import gql from 'graphql-tag';
export default gql`
mutation AddMessage($id: ID!, $username: String!, $message: String!){
	createMessages(input: {
    id: $id
    username: $username
    message: $message
  }) 
  {
    id
    username
    message
  }
}
`;